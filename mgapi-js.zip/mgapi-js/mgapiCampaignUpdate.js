'use strict';

(function() {
	var cid = 'cid',
		name = 'title',
		value = 'New title',
		mg = new MGAPI({		
			apiKey: 'your apiKey'
		});
	
	mg.campaignUpdate(cid, name, value, callback);

	function callback(data) {
		console.log(data);		
	};	
})();