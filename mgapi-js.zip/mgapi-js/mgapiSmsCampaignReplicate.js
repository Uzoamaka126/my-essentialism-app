'use strict';

(function() {
	var cid = 'sms campaign id',
		mg = new MGAPI({
			apiKey: 'your apiKey'
		});
	
	mg.smsCampaignReplicate(cid, callback);

	function callback(data) {
		console.log(data);
	};	
})();