'use strict';

(function() {
	var id = 'listId',
		name = 'title',
		value = 'New title',
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listUpdate(id, name, value, callback);

	function callback(data) {
		console.log(data);
	};	
})();