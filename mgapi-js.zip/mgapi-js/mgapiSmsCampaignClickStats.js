'use strict';

(function() {
	var cid = 'sms campaign id',
		mg = new MGAPI({
			apiKey: 'your apiKey'
		});
	
	mg.smsCampaignClickStats(cid, callback);

	function callback(data) {
		console.log(data);
	};	
})();