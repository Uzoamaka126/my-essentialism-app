'use strict';

(function() {
	var id = 'list Id',
		phone = 'my phone',
		mergeVars = {
			SMS: 'my phone',
			FNAME: 'Joe'
		}, // or mergeVars = {}
		updateExisting = false,
		mg = new MGAPI({
			apiKey: 'your apiKey'
		});
	
	mg.listSubscribeSMS(id, phone, mergeVars, updateExisting, callback);

	function callback(data) {
		console.log(data);
	};	
})();