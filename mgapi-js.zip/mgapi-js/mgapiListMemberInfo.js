'use strict';

(function() {
	var id = 'id',
		emailAddress = 'email',
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listMemberInfo(id, emailAddress, callback);

	function callback(data) {
		console.log(data);		
	};	
})();