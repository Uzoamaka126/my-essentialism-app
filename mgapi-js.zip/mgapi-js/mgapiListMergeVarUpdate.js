'use strict';

(function() {
	var id = 'id',
		tag = 'MERGE_TAG',
		options = {
			req: false,
			name: 'Merge tag name',
			default_value: 'default value',
			show: true
		},		
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listMergeVarUpdate(id, tag, options, callback);

	function callback(data) {
		console.log(data);
	};	
})();