'use strict';

(function() {
	var id = 'list id',
		batch = [
			{
				EMAIL: 'example1@example.org',
				FNAME: 'Joe'
			},
			{
				EMAIL: 'example2@example.org',
				FNAME: 'Richard'
			}
		],
		doubleOptin = true,
		updateExisting = false,
		
		mg = new MGAPI({		
			apiKey: 'your apiKey'
		});
	
	mg.listBatchSubscribe(id, batch, doubleOptin, updateExisting, callback);

	function callback(data) {
		console.log(data);		
	};	
})();