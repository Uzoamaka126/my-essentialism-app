'use strict';

(function() {
	var start = 0,
		limit = 100,
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.lists(start, limit, callback);

	function callback(data) {
		console.log(data);
	};	
})();