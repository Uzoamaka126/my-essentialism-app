'use strict';

(function() {
	var id = 'id',
		status = 'subscribed',
		start = 0,
		limit = 500,		
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listMembers(id, status, start, limit, callback);

	function callback(data) {
		console.log(data);		
	};	
})();