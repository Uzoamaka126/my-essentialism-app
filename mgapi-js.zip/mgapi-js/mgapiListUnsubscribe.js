'use strict';

(function() {
	var id = 'listId',
		emailAddress = 'my email',
		deleteMember = false,
		sendGoodbye = true,
		sendNotify = false,
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listUnsubscribe(id, emailAddress, deleteMember, sendGoodbye, sendNotify, callback);

	function callback(data) {
		console.log(data);
	};	
})();