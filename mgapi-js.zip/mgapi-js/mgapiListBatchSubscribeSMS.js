'use strict';

(function() {
	var id = 'id',
		batch = [{
				SMS: 'my phone',
				FNAME: 'Joe'
			},
			{
				SMS: 'boss phone',
				FNAME: 'Boss'
			}
		],		
		updateExisting = false,
		mg = new MGAPI({		
			apiKey: 'your apiKey'
		});
	
	mg.listBatchSubscribeSMS(id, batch, updateExisting, callback);

	function callback(data) {
		console.log(data);		
	};	
})();