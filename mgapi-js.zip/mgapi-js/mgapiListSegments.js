'use strict';

(function() {
	var id = 'list Id',		
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listSegments(id, callback);

	function callback(data) {
		console.log(data);		
	};	
})();