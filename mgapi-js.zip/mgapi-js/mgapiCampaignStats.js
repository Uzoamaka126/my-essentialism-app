'use strict';

(function() {
	var cid = 'cid',				
		mg = new MGAPI({		
			apiKey: 'your apiKey'
		});
	
	mg.campaignStats(cid, callback);

	function callback(data) {
		console.log(data);		
	};
})();