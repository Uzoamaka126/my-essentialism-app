'use strict';

(function() {
	var	mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.ping(callback);

	function callback(data) {
		console.log(data);
	};	
})();