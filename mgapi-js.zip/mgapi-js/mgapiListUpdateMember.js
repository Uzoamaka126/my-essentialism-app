'use strict';

(function() {
	var id = 'listId',
		emailAddress = 'my email',
		mergeVars = {
			FNAME: 'Richard',
			LNAME: 'Wright'
		}, // or mergeVars = {}
		emailType = 'html',
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listUpdateMember(id, emailAddress, mergeVars, emailType, callback);

	function callback(data) {
		console.log(data);
	};	
})();