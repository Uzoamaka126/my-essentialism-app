'use strict';

(function() {
	var cid = 'cid',
		testEmails = ['myEmail', 'bossManEmail'],
		sendType = 'html',	
		mg = new MGAPI({		
			apiKey: 'your apiKey'
		});
	
	mg.campaignSendTest(cid, testEmails, sendType, callback);

	function callback(data) {
		console.log(data);		
	};	
})();