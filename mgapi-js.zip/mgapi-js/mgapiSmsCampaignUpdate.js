'use strict';

(function() {
	var cid = 'sms campaign id',
		name = 'title',
		value = 'New Title',
		mg = new MGAPI({
			apiKey: 'your apiKey'
		});
	
	mg.smsCampaignUpdate(cid, name, value, callback);

	function callback(data) {
		console.log(data);
	};	
})();