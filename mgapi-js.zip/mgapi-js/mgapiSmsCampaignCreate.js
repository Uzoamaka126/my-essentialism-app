'use strict';

(function() {
	var options = {
			sender: 'sms sender Id',
			recipients: {
				list_id: 'list Id',
				merge: 'sms merge field'
			},
			tracking: {
				clicks: true
			},
			analytics: {
				google: 'my google analytics key'
			},
			title: 'Test SMS Title',
			unicode: true,
			concatenate: true
		},
		content = {
			text: 'some pretty content message'
		},
		mg = new MGAPI({
			apiKey: 'your apiKey'
		});
	
	mg.smsCampaignCreate(options, content, callback);

	function callback(data) {
		console.log(data);
	};	
})();