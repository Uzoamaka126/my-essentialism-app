'use strict';

(function() {
	var emailAddress = 'my email',				
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listsForEmail(emailAddress, callback);

	function callback(data) {
		console.log(data);
	};
})();