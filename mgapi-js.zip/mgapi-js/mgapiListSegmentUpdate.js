'use strict';

(function() {
	var sid = 'sid',
		name = 'title',
		value = 'New title',
		mg = new MGAPI({
			apiKey: 'your apiKey'
		});
	
	mg.listSegmentUpdate(sid, name, value, callback);

	function callback(data) {
		console.log(data);		
	};	
})();