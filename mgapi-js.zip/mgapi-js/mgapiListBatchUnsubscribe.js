'use strict';

(function() {
	var id = 'id',
		emails = [
			'example1@example.org',
			'example2@example.org'
			],
		deleteMember = false,
		sendGoodbye = true,
		sendNotify = false,
		mg = new MGAPI({		
			apiKey: 'your apiKey'
		});
	
	mg.listBatchUnsubscribe(id, emails, deleteMember, sendGoodbye, sendNotify, callback);

	function callback(data) {
		console.log(data);		
	};	
})();