'use strict';

(function() {
	var id = 'id',
		mg = new MGAPI({
			apiKey: 'your apiKey'
		});
	
	mg.listMergeVars(id, callback);

	function callback(data) {
		console.log(data);
	};	
})();