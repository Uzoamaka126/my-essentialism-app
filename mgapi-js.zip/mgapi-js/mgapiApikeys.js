'use strict';

(function() {
	var username = 'username',
		password = 'password',
		expired = true,
		mg = new MGAPI({		
			apiKey: 'your apiKey'
		});
	
	mg.apikeys(username, password, expired, callback);

	function callback(data) {		
		console.log(data);
	};	
})();