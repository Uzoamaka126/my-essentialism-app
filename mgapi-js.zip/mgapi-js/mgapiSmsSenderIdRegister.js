'use strict';

(function() {
	var sender = 'Test sender',
		phone = 'my phone',
		company = 'Company name',
		fullname = 'full name',
		companyPosition = 'developer',
		comments = 'some comments',
		mg = new MGAPI({
			apiKey: 'your apiKey'
		});
	
	mg.smsSenderIdRegister(sender, phone, company, fullname, companyPosition, comments, callback);

	function callback(data) {
		console.log(data);
	};	
})();