'use strict';

(function() {
	var mg = new MGAPI({		
			apiKey: 'your apiKey'
		});
	
	mg.campaignTemplates(callback);

	function callback(data) {
		console.log(data);		
	};	
})();