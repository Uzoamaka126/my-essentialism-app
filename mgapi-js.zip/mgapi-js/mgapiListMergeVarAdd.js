'use strict';

(function() {
	var id = 'id',
		tag = 'MERGE_TAG',
		name = 'Merge Tag name',
		options = {
			field_type: 'text',
			req: false,
			show: true,
			default_value: 'Default value'
		},
		mg = new MGAPI({
			apiKey: 'your apiKey'
		});
	
	mg.listMergeVarAdd(id, tag, name, options, callback);

	function callback(data) {
		console.log(data);		
	};	
})();