'use strict';

(function() {
	var cid = 'sms campaign id',
		start = 0,
		limit = 25,
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.smsCampaignBounces(cid, start, limit, callback);

	function callback(data) {
		console.log(data);
	};	
})();