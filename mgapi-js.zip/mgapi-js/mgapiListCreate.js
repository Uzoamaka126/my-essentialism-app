'use strict';

(function() {
	var title = 'Test list',
		options = {
			permission_reminder: 'Write a short reminder about how the recipient joined your list.',
			notify_to: 'example@example.org',
			subscription_notify: true,
			unsubscription_notify: true,
			has_email_type_option: true
		},	
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listCreate(title, options, callback);

	function callback(data) {
		console.log(data);		
	};	
})();