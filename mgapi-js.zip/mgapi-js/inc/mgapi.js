'use strict';

(function() {
	function MGAPI(params) {
		this.version = '1.5';
		this.apiUrl = 'http://api.mailigen.com/';
		if (params && params.apiKey) {
			this.apiKey = params.apiKey;
		}
	};

	function getXmlHttp(){
		var xmlhttp;
		try {
		    xmlhttp = new ActiveXObject('Msxml2.XMLHTTP');
	  	}
	  	catch (e) {
	    	try {
	      		xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
	    	} catch (E) {
	      		xmlhttp = false;
	    	}
	  	}
		if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
			xmlhttp = new XMLHttpRequest();
		}
	  	return xmlhttp;
	};

	var objectToQueryString = function (a) {
        var prefix, s, add, name, r20, output;
        s = [];
        r20 = /%20/g;
        add = function (key, value) {
            value = ( typeof value == 'function' ) ? value() : ( value == null ? '' : value );
            s[ s.length ] = encodeURIComponent(key) + '=' + encodeURIComponent(value);
        };
        if (a instanceof Array) {        	
            for (name in a) {
                add(name, a[name]);
            }
		} else {
            for (prefix in a) {            	
                buildParams(prefix, a[ prefix ], add);
            }
        }
        output = s.join('&').replace(r20, '+');
        if (output)
        	output = '&' + output;
        return output;
    };

    function buildParams(prefix, obj, add) {
        var name, i, l, rbracket;
        rbracket = /\[\]$/;
        if (obj instanceof Array) {        	
            for (i = 0, l = obj.length; i < l; i++) {
                if (rbracket.test(prefix)) {                	
                    add(prefix, obj[i]);
                } else {          	
                    buildParams(prefix + '[' + i + ']', obj[i], add);
                }
            }
            if (!obj.length) {            	
            	add(prefix + '[]', obj);
            }
        } else if (typeof obj == 'object') {
            for (name in obj) {
                buildParams(prefix + '[' + name + ']', obj[ name ], add);
            }
            if (!name) {            
        		add(prefix + '[]', obj);
        	}
        } else {
            add(prefix, obj);
        }
    };


	MGAPI.prototype.callServer = function callServer(method, params, callback) {
		var query = objectToQueryString(params);
		
		var xhr = getXmlHttp();
		xhr.open('POST', this.apiUrl + this.version + '/?output=json', true);		
		xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded')
		xhr.onreadystatechange = function() {
	  		if (xhr.readyState == 4) {
	     		if(xhr.status == 200 && callback) {
	     			callback(xhr.responseText);
	     		} else {
	     			alert(xhr.statusText);
	     		}
	     	}
     	};
	 	xhr.send('apikey=' + this.apiKey + '&method=' + method + query);
	};	

	MGAPI.prototype.campaignUnschedule = function campaignUnschedule(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('campaignUnschedule', params, callback);
		return this;
	};

	MGAPI.prototype.campaignSchedule = function campaignSchedule(cid, scheduleTime, callback) {
		var params = {};
		params['cid'] = cid;
		params['schedule_time'] = scheduleTime;		
		this.callServer('campaignSchedule', params, callback);
		return this;	
	};

	MGAPI.prototype.campaignResume = function campaignResume(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('campaignResume', params, callback);
		return this;
	};

	MGAPI.prototype.campaignPause = function campaignPause(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('campaignPause', params, callback);
		return this;
	};

	MGAPI.prototype.campaignSendNow = function campaignSendNow(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('campaignSendNow', params, callback);
		return this;		
	};

	MGAPI.prototype.campaignSendTest = function campaignSendTest(cid, testEmails, sendType, callback) {
		var params = {};
		params['cid'] = cid;
		params['test_emails'] = (typeof testEmails === 'undefined') ? [] : testEmails;
		params['send_type'] = (typeof sendType === 'undefined') ? null : sendType;
		this.callServer('campaignSendTest', params, callback);
		return this;
	};

	MGAPI.prototype.campaignTemplates = function campaignTemplates(callback) {
		var params = {};
		this.callServer('campaignTemplates', params, callback);
		return this;
	};

	MGAPI.prototype.campaignCreate = function campaignCreate(type, options, content, typeOpts, callback) {
		var params = {};
		params['type'] = type;
		params['options'] = options;
		params['content'] = content;
		params['type_opts'] = (typeof typeOpts === 'undefined') ? null : typeOpts;
		this.callServer('campaignCreate', params, callback);
		return this;
	};

	MGAPI.prototype.campaignUpdate = function campaignUpdate(cid, name, value, callback) {
		var params = {};
		params['cid'] = cid;
		params['name'] = name;
		params['value'] = value;
		this.callServer('campaignUpdate', params, callback);
		return this;
	};

	MGAPI.prototype.campaignReplicate = function campaignReplicate(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('campaignReplicate', params, callback);
		return this;
	};

	MGAPI.prototype.campaignDelete = function campaignDelete(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('campaignDelete', params, callback);
		return this;
	};

	MGAPI.prototype.campaigns = function campaigns(filters, start, limit, callback) {
		var params = {};
		params['filters'] = [];
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 25 : limit;
		this.callServer('campaigns', params, callback);
		return this;
	};

	MGAPI.prototype.campaignStats = function campaignStats(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('campaignStats', params, callback);
		return this;
	};

	MGAPI.prototype.campaignClickStats = function campaignClickStats(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('campaignClickStats', params, callback);
		return this;
	};

	MGAPI.prototype.campaignEmailDomainPerformance = function campaignEmailDomainPerformance(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('campaignEmailDomainPerformance', params, callback);
		return this;
	};

	MGAPI.prototype.campaignHardBounces = function campaignHardBounces(cid, start, limit, callback) {
		var params = {};
		params['cid'] = cid;
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 1000 : limit;
		this.callServer('campaignHardBounces', params, callback);
		return this;
	};

	MGAPI.prototype.campaignSoftBounces = function campaignSoftBounces(cid, start, limit, callback) {
		var params = {};
		params['cid'] = cid;
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 1000 : limit;
		this.callServer('campaignSoftBounces', params, callback);
		return this;
	};

	MGAPI.prototype.campaignBlockedBounces = function campaignBlockedBounces(cid, start, limit, callback) {
		var params = {};
		params['cid'] = cid;
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 1000 : limit;
		this.callServer('campaignBlockedBounces', params, callback);
		return this;
	};

	MGAPI.prototype.campaignTemporaryBounces = function campaignTemporaryBounces(cid, start, limit, callback) {
		var params = {};
		params['cid'] = cid;
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 1000 : limit;
		this.callServer('campaignTemporaryBounces', params, callback);
		return this;
	};

	MGAPI.prototype.campaignGenericBounces = function campaignGenericBounces(cid, start, limit, callback) {
		var params = {};
		params['cid'] = cid;
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 1000 : limit;
		this.callServer('campaignGenericBounces', params, callback);
		return this;
	};

	MGAPI.prototype.campaignUnsubscribes = function campaignUnsubscribes(cid, start, limit, callback) {
		var params = {};
		params['cid'] = cid;
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 1000 : limit;
		this.callServer('campaignUnsubscribes', params, callback);
		return this;
	};

	MGAPI.prototype.campaignGeoOpens = function campaignGeoOpens(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('campaignGeoOpens', params, callback);
		return this;
	};

	MGAPI.prototype.campaignForwardStats = function campaignForwardStats(cid, start, limit, callback) {
		var params = {};
		params['cid'] = cid;
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 1000 : limit;
		this.callServer('campaignForwardStats', params, callback);
		return this;
	};

	MGAPI.prototype.campaignBounceMessages = function campaignBounceMessages(cid, start, limit, callback) {
		var params = {};
		params['cid'] = cid;
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 25 : limit;
		this.callServer('campaignBounceMessages', params, callback);
		return this;
	};

	MGAPI.prototype.campaignOpened = function campaignOpened(cid, start, limit, callback) {
		var params = {};
		params['cid'] = cid;
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 25 : limit;
		this.callServer('campaignOpened', params, callback);
		return this;
	};

	MGAPI.prototype.campaignNotOpened = function campaignNotOpened(cid, start, limit, callback) {
		var params = {};
		params['cid'] = cid;
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 25 : limit;
		this.callServer('campaignNotOpened', params, callback);
		return this;
	};

	MGAPI.prototype.listCreate = function listCreate(title, options, callback) {
		var params = {};
		params['title'] = title;
		params['options'] = (typeof options === 'undefined') ? null : options;
		this.callServer('listCreate', params, callback);
		return this;
	};

	MGAPI.prototype.listUpdate = function listUpdate(id, name, value, callback) {
		var params = {};
		params['id'] = id;
		params['name'] = name;
		params['value'] = value;
		this.callServer('listUpdate', params, callback);
		return this;
	};

	MGAPI.prototype.listDelete = function listDelete(id, callback) {
		var params = {};
		params['id'] = id;
		this.callServer('listDelete', params, callback);
		return this;
	};

	MGAPI.prototype.lists = function lists(start, limit, callback) {
		var params = {};
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 1000 : limit;
		this.callServer('lists', params, callback);
		return this;
	};

	MGAPI.prototype.listMergeVars = function listMergeVars(id, callback) {
		var params = {};
		params['id'] = id;
		this.callServer('listMergeVars', params, callback);
		return this;
	};

	MGAPI.prototype.listMergeVarAdd = function listMergeVarAdd(id, tag, name, options, callback) {
		var params = {};
		params['id'] = id;
		params['tag'] = tag;
		params['name'] = name;
		params['options'] = (typeof options === 'undefined') ? [] : options;
		this.callServer('listMergeVarAdd', params, callback);
		return this;
	};

	MGAPI.prototype.listMergeVarUpdate = function listMergeVarUpdate(id, tag, options, callback) {
		var params = {};
		params['id'] = id;
		params['tag'] = tag;		
		params['options'] = options;
		this.callServer('listMergeVarUpdate', params, callback);
		return this;
	};

	MGAPI.prototype.listMergeVarDel = function listMergeVarDel(id, tag, callback) {
		var params = {};
		params['id'] = id;
		params['tag'] = tag;
		this.callServer('listMergeVarDel', params, callback);
		return this;
	};

	MGAPI.prototype.listSubscribe = function listSubscribe(id, emailAddress, mergeVars, emailType, doubleOptin, updateExisting, sendWelcome, callback) {
		var params = {};
		params['id'] = id;
		params['email_address'] = emailAddress;
		params['merge_vars'] = mergeVars;
		params['email_type'] = (typeof emailType === 'undefined') ? 'html' : emailType;
		params['double_optin'] = (typeof doubleOptin === 'undefined') ? true : doubleOptin;
		params['update_existing'] = (typeof updateExisting === 'undefined') ? false : updateExisting;
		params['send_welcome'] = (typeof sendWelcome === 'undefined') ? false : sendWelcome;
		this.callServer('listSubscribe', params, callback);
		return this;
	};

	MGAPI.prototype.listSubscribeSMS = function listSubscribeSMS(id, phone, mergeVars, updateExisting, callback) {
		var params = {};
		params['id'] = id;
		params['phone'] = phone;
		params['merge_vars'] = mergeVars;
		params['update_existing'] = (typeof updateExisting === 'undefined') ? false : updateExisting;
		this.callServer('listSubscribeSMS', params, callback);
		return this;
	};

	MGAPI.prototype.listUnsubscribe = function listUnsubscribe(id, emailAddress, deleteMember, sendGoodbye, sendNotify, callback) {
		var params = {};
		params['id'] = id;
		params['email_address'] = emailAddress;
		params['delete_member'] = (typeof deleteMember === 'undefined') ? false : deleteMember;
		params['send_goodbye'] = (typeof sendGoodbye === 'undefined') ? true : sendGoodbye;
		params['send_notify'] = (typeof sendNotify === 'undefined') ? true : sendNotify;
		this.callServer('listUnsubscribe', params, callback);
		return this;
	};

	MGAPI.prototype.listUnsubscribeSMS = function listUnsubscribeSMS(id, phone, deleteMember, sendNotify, callback) {
		var params = {};
		params['id'] = id;
		params['phone'] = phone;
		params['delete_member'] = (typeof deleteMember === 'undefined') ? false : deleteMember;
		params['send_notify'] = (typeof sendNotify === 'undefined') ? true : sendNotify;
		this.callServer('listUnsubscribeSMS', params, callback);
		return this;
	};

	MGAPI.prototype.listUpdateMember = function listUpdateMember(id, emailAddress, mergeVars, emailType, callback) {
		var params = {};
		params['id'] = id;
		params['email_address'] = emailAddress;
		params['merge_vars'] = mergeVars;		
		params['email_type'] = (typeof emailType === 'undefined') ? '' : emailType;
		this.callServer('listUpdateMember', params, callback);
		return this;
	};

	MGAPI.prototype.listBatchSubscribe = function listBatchSubscribe(id, batch, doubleOptin, updateExisting, callback) {
		var params = {};
		params['id'] = id;
		params['batch'] = batch;		
		params['double_optin'] = (typeof doubleOptin === 'undefined') ? true : doubleOptin;
		params['update_existing'] = (typeof updateExisting === 'undefined') ? false : updateExisting;		
		this.callServer('listBatchSubscribe', params, callback);
		return this;
	};

	MGAPI.prototype.listBatchSubscribeSMS = function listBatchSubscribeSMS(id, batch, updateExisting, callback) {
		var params = {};
		params['id'] = id;
		params['batch'] = batch;		
		params['update_existing'] = (typeof updateExisting === 'undefined') ? false : updateExisting;
		this.callServer('listBatchSubscribeSMS', params, callback);
		return this;
	};

	MGAPI.prototype.listBatchUnsubscribe = function listBatchUnsubscribe(id, emails, deleteMember, sendGoodbye, sendNotify, callback) {
		var params = {};
		params['id'] = id;
		params['emails'] = emails;
		params['delete_member'] = (typeof deleteMember === 'undefined') ? false : deleteMember;
		params['send_goodbye'] = (typeof sendGoodbye === 'undefined') ? true : sendGoodbye;
		params['send_notify'] = (typeof sendNotify === 'undefined') ? false : sendNotify;
		this.callServer('listBatchUnsubscribe', params, callback);
		return this;
	};

	MGAPI.prototype.listBatchUnsubscribeSMS = function listBatchUnsubscribeSMS(id, phones, deleteMember, sendNotify, callback) {
		var params = {};
		params['id'] = id;
		params['phones'] = phones;
		params['delete_member'] = (typeof deleteMember === 'undefined') ? false : deleteMember;		
		params['send_notify'] = (typeof sendNotify === 'undefined') ? false : sendNotify;
		this.callServer('listBatchUnsubscribeSMS', params, callback);
		return this;
	};

	MGAPI.prototype.listMembers = function listMembers(id, status, start, limit, callback) {
		var params = {};
		params['id'] = id;
		params['status'] = (typeof status === 'undefined') ? 'subscribed' : status;
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 100 : limit;
		this.callServer('listMembers', params, callback);
		return this;
	};

	MGAPI.prototype.listMemberInfo = function listMemberInfo(id, emailAddress, callback) {
		var params = {};
		params['id'] = id;
		params['email_address'] = emailAddress;
		this.callServer('listMemberInfo', params, callback);
		return this;
	};

	MGAPI.prototype.listGrowthHistory = function listGrowthHistory(id, callback) {
		var params = {};
		params['id'] = id;		
		this.callServer('listGrowthHistory', params, callback);
		return this;
	};

	MGAPI.prototype.listSegments = function listSegments(id, callback) {
		var params = {};
		params['id'] = id;
		this.callServer('listSegments', params, callback);
		return this;
	};

	MGAPI.prototype.listSegmentCreate = function listSegmentCreate(list, title, match, filter, callback) {
		var params = {};
		params['list'] = list;		
		params['title'] = title;		
		params['match'] = match;
		params['filter'] = filter;		
		this.callServer('listSegmentCreate', params, callback);
		return this;
	};

	MGAPI.prototype.listSegmentUpdate = function listSegmentUpdate(sid, name, value, callback) {
		var params = {};
		params['sid'] = sid;
		params['name'] = name;
		params['value'] = value;
		this.callServer('listSegmentUpdate', params, callback);
		return this;
	};

	MGAPI.prototype.listSegmentDelete = function listSegmentDelete(sid, callback) {
		var params = {};
		params['sid'] = sid;
		this.callServer('listSegmentDelete', params, callback);
		return this;
	};

	MGAPI.prototype.smsCampaignUnschedule = function smsCampaignUnschedule(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('smsCampaignUnschedule', params, callback);
		return this;
	};

	MGAPI.prototype.smsCampaignSchedule = function smsCampaignSchedule(cid, scheduleTime, callback) {
		var params = {};
		params['cid'] = cid;
		params['schedule_time'] = scheduleTime;
		this.callServer('smsCampaignSchedule', params, callback);
		return this;
	};

	MGAPI.prototype.smsCampaignSendNow = function smsCampaignSendNow(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('smsCampaignSendNow', params, callback);
		return this;
	};

	MGAPI.prototype.smsCampaignTemplates = function smsCampaignTemplates(callback) {
		var params = {};
		this.callServer('smsCampaignTemplates', params, callback);
		return this;
	};

	MGAPI.prototype.smsCampaignCreate = function smsCampaignCreate(options, content, callback) {
		var params = {};
		params['options'] = options;
		params['content'] = content;		
		this.callServer('smsCampaignCreate', params, callback);
		return this;
	};

	MGAPI.prototype.smsCampaignUpdate = function smsCampaignUpdate(cid, name, value, callback) {
		var params = {};
		params['cid'] = cid;
		params['name'] = name;		
		params['value'] = value;		
		this.callServer('smsCampaignUpdate', params, callback);
		return this;
	};

	MGAPI.prototype.smsCampaignReplicate = function smsCampaignReplicate(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('smsCampaignReplicate', params, callback);
		return this;
	};

	MGAPI.prototype.smsCampaignDelete = function smsCampaignDelete(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('smsCampaignDelete', params, callback);
		return this;
	};

	MGAPI.prototype.smsCampaigns = function smsCampaigns(filters, start, limit, callback) {
		var params = {};
		params['filters'] = (typeof filters === 'undefined') ? [] : filters;
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 25 : limit;	
		this.callServer('smsCampaigns', params, callback);
		return this;
	};

	MGAPI.prototype.smsCampaignStats = function smsCampaignStats(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('smsCampaignStats', params, callback);
		return this;
	};

	MGAPI.prototype.smsCampaignClickStats = function smsCampaignClickStats(cid, callback) {
		var params = {};
		params['cid'] = cid;
		this.callServer('smsCampaignClickStats', params, callback);
		return this;
	};

	MGAPI.prototype.smsCampaignBounces = function smsCampaignBounces(cid, start, limit, callback) {
		var params = {};
		params['cid'] = cid;
		params['start'] = (typeof start === 'undefined') ? 0 : start;
		params['limit'] = (typeof limit === 'undefined') ? 25 : limit;
		this.callServer('smsCampaignBounces', params, callback);
		return this;
	};

	MGAPI.prototype.smsSenderIdRegister = function smsSenderIdRegister(sender, phone, company, fullname, companyposition, comments, callback) {
		var params = {};
		params['sender'] = sender;
		params['phone'] = phone;		
		params['company'] = company;
		params['fullname'] = fullname;
		params['companyposition'] = companyposition;
		params['comments'] = (typeof comments === 'undefined') ? '' : comments;
		this.callServer('smsSenderIdRegister', params, callback);
		return this;
	};

	MGAPI.prototype.getAccountDetails = function getAccountDetails(callback) {
		var params = {};
		this.callServer('getAccountDetails', params, callback);
		return this;
	};

	MGAPI.prototype.listsForEmail = function listsForEmail(emailAddress, callback) {
		var params = {};
		params['email_address'] = emailAddress;
		this.callServer('listsForEmail', params, callback);
		return this;
	};

	MGAPI.prototype.apikeys = function apikeys(username, password, expired, callback) {
		var params = {};
		params['username'] = username;
		params['password'] = password;
		params['expired'] = (typeof expired === 'undefined') ? false : expired;
		this.callServer('apikeys', params, callback);
		return this;
	};

	MGAPI.prototype.apikeyAdd = function apikeyAdd(username, password, callback) {
		var params = {};
		params['username'] = username;
		params['password'] = password;
		this.callServer('apikeyAdd', params, callback);
		return this;
	};

	MGAPI.prototype.apikeyExpire = function apikeyExpire(username, password, callback) {
		var params = {};
		params['username'] = username;
		params['password'] = password;
		this.callServer('apikeyExpire', params, callback);
		return this;
	};

	MGAPI.prototype.login = function login(username, password, callback) {
		var params = {};
		params['username'] = username;
		params['password'] = password;
		this.callServer('login', params, callback);
		return this;
	};

	MGAPI.prototype.ping = function ping(callback) {
		var params = {};
		this.callServer('ping', params, callback);
		return this;
	};

	window.MGAPI = MGAPI;
})();