'use strict';

(function() {
	var id = 'list Id',
		emailAddress = 'my email',
		mergeVars = {
			EMAIL: 'my email',
			FNAME: 'Joe'
		},
		emailType = 'html',
		doubleOptin = true,
		updateExisting = false,
		sendWelcome = false,			
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listSubscribe(id, emailAddress, mergeVars, emailType, doubleOptin, updateExisting, sendWelcome, callback);

	function callback(data) {
		console.log(data);
	};	
})();