'use strict';

(function() {
	var id = 'id',			
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listDelete(id, callback);

	function callback(data) {
		console.log(data);		
	};	
})();