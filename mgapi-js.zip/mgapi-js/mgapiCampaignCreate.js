'use strict';

(function() {
	var type = 'html',
		options = {
			list_id: 'listId',
			segment_id: [
				'segment id 1',
				'segment id 2'
			],
			subject: 'Test Newsletter Subject',
			from_email: 'example@example.org',
			from_name: 'DEMO, Inc.',
			tracking: {
				opens: true,
				html_clicks: true,
				text_clicks: false
			},
			analytics: {
				google: 'my_google_analytics_key'
			},
			title: 'Test Newsletter Title'
		},
		content = {			
			html: '<div>Some HTML content.</div>',
			plain: true
		},
		typeOpts = 'typeOpts',
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});


	mg.campaignCreate(type, options, content, typeOpts, callback);

	function callback(data) {
		console.log(data);
	};
})();