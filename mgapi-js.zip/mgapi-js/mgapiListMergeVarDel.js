'use strict';

(function() {
	var id = 'id',
		tag = 'MERGE_TAG',		
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listMergeVarDel(id, tag, callback);

	function callback(data) {
		console.log(data);		
	};	
})();