'use strict';

(function() {
	var id = 'id',
		phones = [
			'my phone',
			'my boss phone'
			],
		deleteMember = false,
		sendNotify = false,
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listBatchUnsubscribeSMS(id, phones, deleteMember, sendNotify, callback);

	function callback(data) {
		console.log(data);		
	};	
})();