'use strict';

(function() {
	var cid = 'sms campaign id',
		scheduleTime = '2020-05-18 11:59:21',
		mg = new MGAPI({
			apiKey: 'your apiKey'
		});
	
	mg.smsCampaignSchedule(cid, scheduleTime, callback);

	function callback(data) {
		console.log(data);
	};	
})();