'use strict';

(function() {
	var cid = 'cid',
		mg = new MGAPI({		
			apiKey: 'your apiKey'
		});

	mg.campaignPause(cid, callback);	

	function callback(data) {
		console.log(data);
	};
})();