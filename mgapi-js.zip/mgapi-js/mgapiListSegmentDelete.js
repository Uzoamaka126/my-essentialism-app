'use strict';

(function() {
	var sid = 'sid',
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listSegmentDelete(sid, callback);

	function callback(data) {
		console.log(data);		
	};	
})();