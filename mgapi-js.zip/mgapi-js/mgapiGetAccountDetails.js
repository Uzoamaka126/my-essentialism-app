'use strict';

(function() {
	var mg = new MGAPI({
			apiKey: 'your apiKey'
		});

	mg.getAccountDetails(callback);

	function callback(data) {
		console.log(data);
	};
})();