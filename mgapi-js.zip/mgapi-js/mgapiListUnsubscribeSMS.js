'use strict';

(function() {
	var id = 'listId',
		phone = 'my phone',
		deleteMember = false,		
		sendNotify = false,
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listUnsubscribeSMS(id, phone, deleteMember, sendNotify, callback);

	function callback(data) {
		console.log(data);
	};	
})();