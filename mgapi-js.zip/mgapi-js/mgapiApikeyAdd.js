'use strict';

(function() {
	var username = 'username',
		password = 'password',
		mg = new MGAPI({		
			apiKey: 'your apiKey'
		});
	
	mg.apikeyAdd(username, password, callback);

	function callback(data) {
		console.log(data);
	};	
})();