'use strict';

(function() {
	var filters = [],
		start = 0,
		limit = 25,
		mg = new MGAPI({
			apiKey: 'your apiKey'
		});
	
	mg.smsCampaigns(filters, start, limit, callback);

	function callback(data) {
		console.log(data);
	};
})();