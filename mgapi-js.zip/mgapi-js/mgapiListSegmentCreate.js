'use strict';

(function() {
	var list = 'list Id',
		title = 'Test Segment',
		match = 'all', // any, or, all, and
		filter = [
			{
				field: 'merge0',
				condition: 'ends', //is, not, isany, contains, notcontain, starts, ends, greater, less
				value: '@gmail.com'
			},
			{
				field: 'confirm_time',
        		condition: 'greater',
        		value: '2013-01-01'
			}
		],
		mg = new MGAPI({	
			apiKey: 'your apiKey'
		});
	
	mg.listSegmentCreate(list, title, match, filter, callback);

	function callback(data) {
		console.log(data);		
	};	
})();