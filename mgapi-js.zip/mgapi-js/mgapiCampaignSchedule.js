'use strict';

(function() {
	var cid = 'cid',
		scheduleTime = 'schedule_time',
		mg = new MGAPI({		
			apiKey: 'your apiKey'
		});
	
	mg.campaignSchedule(cid, scheduleTime, callback);

	function callback(data) {
		console.log(data);		
	};
})();