'use strict';

(function() {
	var cid = 'cid',
		mg = new MGAPI({		
			apiKey: 'your apiKey'
		});
	
	mg.campaignDelete(cid, callback);

	function callback(data) {
		console.log(data);
	};	
})();