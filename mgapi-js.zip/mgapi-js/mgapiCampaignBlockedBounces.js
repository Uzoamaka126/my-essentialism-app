'use strict';

(function() {
	var cid = 'cid',
		start = 0,
		limit = 1000,
		mg = new MGAPI({		
			apiKey: 'your apiKey'
		});
	
	mg.campaignBlockedBounces(cid, start, limit, callback);

	function callback(data) {
		console.log(data);
	};	
})();